# ScanMarket - Smart Receipt Scanner

A React Native/Expo web application with real-time receipt detection and automatic scanning capabilities.

## 🚀 Live Demo
Visit the live app at: https://mobinalkhn.github.io/last

## ✨ Features

### 📱 Core Functionality
- **Real-time Receipt Detection**: Automatically detects receipts in camera view
- **Smart Auto-Capture**: Captures receipt images without manual button press
- **OCR Text Extraction**: Extracts text from receipts using OCR.space API
- **Product Information**: Gets product details from OpenFoodFacts API

### 🎯 Auto-Detection System
- **Visual Analysis**: Fast pixel-based receipt detection
- **Text Recognition**: Identifies receipt-specific keywords
- **Smart Capture**: Auto-captures when receipt is detected
- **Manual Fallback**: Manual capture button available

### 🔧 Technical Features
- **Cross-Platform**: Works on web, Android, and iOS
- **Responsive Design**: Material Design UI with React Native Paper
- **Camera Access**: Environment-facing camera with full-screen view
- **Real-time Processing**: 60fps visual analysis with smart OCR limiting

## 🛠 Technologies Used
- **React Native & Expo**: Cross-platform framework
- **React Native Paper**: Material Design components
- **OCR.space API**: Text recognition service
- **OpenFoodFacts API**: Product information database
- **TypeScript**: Type-safe development

## 📦 Installation

1. Clone the repository:
```bash
git clone https://github.com/mobinalkhn/last.git
cd last
```

2. Install dependencies:
```bash
npm install
```

3. Start development server:
```bash
npm start
```

4. Open in browser:
```bash
# Press 'w' to open web version
# Or visit http://localhost:8081
```

## 🌐 Deployment

### Web Build
```bash
npx expo export --platform web
```

### GitHub Pages
1. Build the project: `npx expo export --platform web`
2. The `dist/` folder contains the deployable files
3. Deploy to your hosting service or GitHub Pages

## 🎨 UI Features
- **ScanMarket Branding**: Shopping cart logo with purple theme
- **Step-by-step Guide**: Clear instructions for users
- **Full-screen Camera**: Immersive scanning experience
- **Real-time Feedback**: Live status updates during scanning
- **Clean Interface**: Modern Material Design

## 🔑 API Keys
The app uses:
- OCR.space API for text recognition
- OpenFoodFacts API for product information

## 📱 Usage
1. **Open Camera**: Click "📷 Scan Receipt" button
2. **Point at Receipt**: Position receipt in camera view
3. **Auto-Detection**: App automatically detects and captures receipt
4. **View Results**: Extracted text and product info displayed
5. **Manual Override**: Use manual capture if needed

## 🚀 Performance
- **Real-time Analysis**: 60fps visual processing
- **Smart OCR**: Only processes promising frames
- **Fast Capture**: Instant high-quality image capture
- **Optimized Loading**: Efficient asset management

## 📁 Project Structure
```
├── app/                    # Main app screens
├── components/            # Reusable components
│   ├── ReceiptScanner.tsx # Core scanning component
│   └── ProductDetails.tsx # Product info display
├── assets/               # Images and icons
├── dist/                # Built web files (auto-generated)
└── package.json         # Dependencies and scripts
```

---

Made with ❤️ using React Native & Expo